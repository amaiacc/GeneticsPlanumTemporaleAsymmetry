function [nm,nv]=char(m);
nm=char(m.mean);
nv=char(m.variance);